package simple.stocks.implementations;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import simple.stocks.domain.StockType;
import simple.stocks.domain.TradeIndicator;
import simple.stocks.domain.TradeRecord;
import simple.stocks.interfaces.Stock;

public class StockImplTest {
	
	@Test(expected=IllegalArgumentException.class)
	public void calculateDividendYield_PassedNegativeMarketPrice_ThrowsIllegalArgumentException() throws Exception {
		Stock stock = new StockImpl();
		double negativeMarketPrice = -120.0;
		stock.calculateDividendYield(negativeMarketPrice);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void calculateDividendYield_PassedZeroMarketPrice_ThrowsIllegalArgumentException() throws Exception {
		Stock stock = new StockImpl();
		double zeroMarketPrice = 0;
		stock.calculateDividendYield(zeroMarketPrice);
	}
	
	@Test(expected=Exception.class)
	public void calculateDividendYield_PassedAPrefferedStock_ThrowsException() throws Exception {
		String symbol = "GIN";
		StockType type = StockType.PREFERRED;
		double lastDividend = 8.0;
		int parValue = 100;
		Stock stock = new StockImpl(symbol,type,lastDividend,parValue);
		double correctMarketPrice = 120.0;
		//This should throw an exception if called on a Preffered stock
		stock.calculateDividendYield(correctMarketPrice);		
	}

	@Test
	public void calculateDividendYield_PassedCorrectMarketPriceForCommonSymbol_ReturnsCorrectDividendYield() throws Exception {
		String symbol = "POP";
		StockType type = StockType.COMMON;
		double lastDividend = 8.0;
		int parValue = 100;
		Stock stock = new StockImpl(symbol,type,lastDividend,parValue);
		double correctMarketPrice = 120.0;
		double actualDividendYield = stock.calculateDividendYield(correctMarketPrice);
		double expectedDividendYield = 8.0/120.0;		
		assertTrue(actualDividendYield == expectedDividendYield);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void calculateDividendYield_PassedNegativeMarketPriceAndValidFixedDividend_ThrowsIllegalArgumentException() throws Exception {
		String symbol = "GIN";
		StockType type = StockType.PREFERRED;
		double lastDividend = 8.0;
		int parValue = 100;
		Stock stock = new StockImpl(symbol,type,lastDividend,parValue);
		double correctMarketPrice = -120.0;
		double fixedDividend = 0.02;
		stock.calculateDividendYield(correctMarketPrice,fixedDividend);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void calculateDividendYield_PassedZeroMarketPriceAndValidFixedDividend_ThrowsIllegalArgumentException() throws Exception {
		String symbol = "GIN";
		StockType type = StockType.PREFERRED;
		double lastDividend = 8.0;
		int parValue = 100;
		Stock stock = new StockImpl(symbol,type,lastDividend,parValue);
		double correctMarketPrice = 0.0;
		double fixedDividend = 0.02;
		stock.calculateDividendYield(correctMarketPrice,fixedDividend);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void calculateDividendYield_PassedValidMarketPriceAndNegativeFixedDividend_ThrowsIllegalArgumentException() throws Exception {
		String symbol = "GIN";
		StockType type = StockType.PREFERRED;
		double lastDividend = 8.0;
		int parValue = 100;
		Stock stock = new StockImpl(symbol,type,lastDividend,parValue);
		double correctMarketPrice = 120.0;
		double fixedDividend = -0.02;
		stock.calculateDividendYield(correctMarketPrice,fixedDividend);
	}
	
	@Test(expected=Exception.class)
	public void calculateDividendYield_PassedCommonStockType_ThrowsIllegalArgumentException() throws Exception {
		String symbol = "POP";
		StockType type = StockType.COMMON;
		double lastDividend = 8.0;
		int parValue = 100;
		Stock stock = new StockImpl(symbol,type,lastDividend,parValue);
		double correctMarketPrice = 120.0;
		double fixedDividend = 0.02;
		stock.calculateDividendYield(correctMarketPrice,fixedDividend);
	}
	
	@Test
	public void calculateDividendYield_PassedCorrectMarketPriceForPreferedSymbol_ReturnsCorrectDividendYield() throws Exception {
		String symbol = "GIN";
		StockType type = StockType.PREFERRED;
		double lastDividend = 8.0;
		int parValue = 100;
		Stock stock = new StockImpl(symbol,type,lastDividend,parValue);
		double correctMarketPrice = 120.0;
		double fixedDividend = 0.02;
		double actualDividendYield = stock.calculateDividendYield(correctMarketPrice,fixedDividend);
		double expectedDividendYield = ((fixedDividend * parValue) / (correctMarketPrice));		
		assertTrue(actualDividendYield == expectedDividendYield);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void calculate_P_E_Ratio_PassedNegativeMarketPrice_ThrowsIllegalArgumentException() {
		Stock stock = new StockImpl();
		double negativeMarketPrice = -120.0;
		stock.calculate_P_E_Ratio(negativeMarketPrice);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void calculate_P_E_Ratio_PassedZeroMarketPrice_ThrowsIllegalArgumentException() {
		Stock stock = new StockImpl();
		double zeroMarketPrice = 0;
		stock.calculate_P_E_Ratio(zeroMarketPrice);
	}
	
	@Test
	public void calculate_P_E_Ratio_PassedCorrectMarketPrice_ReturnsCorrect_P_E_Ratio() {
		String symbol = "GIN";
		StockType type = StockType.PREFERRED;
		double lastDividend = 8.0;
		int parValue = 100;
		Stock stock = new StockImpl(symbol,type,lastDividend,parValue);
		double correctMarketPrice = 120.0;
		double actual_P_E_Ratio = stock.calculate_P_E_Ratio(correctMarketPrice);
		double expected_P_E_Ratio = (correctMarketPrice/lastDividend);		
		assertTrue(actual_P_E_Ratio == expected_P_E_Ratio);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void recordTrade_PassedNullTradeRecord_ThrownsIllegalArgumentException() {
		String symbol = "GIN";
		StockType type = StockType.PREFERRED;
		double lastDividend = 8.0;
		int parValue = 100;
		Stock stock = new StockImpl(symbol,type,lastDividend,parValue);
		TradeRecord tradeRecord = null;	
		stock.recordTrade(tradeRecord);
	}
	
	@Test
	public void recordTrade_PassedValidRecord_SavesRecord() {
		String symbol = "GIN";
		StockType type = StockType.PREFERRED;
		double lastDividend = 8.0;
		int parValue = 100;
		Stock stock = new StockImpl(symbol,type,lastDividend,parValue);
		String timeStamp = "4-14-2016 10:30:00";
		long numShares = 1000;
		TradeIndicator indicator = TradeIndicator.BUY;
		double tradePrice = 100.0;		
		assertTrue(stock.recordTrade(new TradeRecord(timeStamp,numShares,indicator,tradePrice)));
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void calculateVolWeightedStockPrice_PassedEmptyTradeRecordsToSave_ThrownsIllegalArgumentException() {
		String symbol = "GIN";
		StockType type = StockType.PREFERRED;
		double lastDividend = 8.0;
		int parValue = 100;
		Stock stock = new StockImpl(symbol,type,lastDividend,parValue);
		List<TradeRecord> tradeRecords = null;
		stock.calculateVolWeightedStockPrice(tradeRecords);
	}
	
	@Test
	public void calculateVolWeightedStockPrice_PassedInValidTradesToSave_ReturnsCorrectVolWeightedStockPrice() {
		String symbol = "GIN";
		StockType type = StockType.PREFERRED;
		double lastDividend = 8.0;
		int parValue = 100;
		Stock stock = new StockImpl(symbol,type,lastDividend,parValue);
		List<TradeRecord> tradeRecords = new ArrayList<>();
		//15 trade records, one every minute
		for (int i = 0; i < 15; i++){
			tradeRecords.add(new TradeRecord("4-14-2016 10:0" + i + ":00",0 + i,TradeIndicator.BUY,0.0 + i));
		}
		double actualVolWeightStockPrice = stock.calculateVolWeightedStockPrice(tradeRecords);
		System.out.println(actualVolWeightStockPrice);
		double expectedVolWeightStockPrice = 29.0/3.0;
		assertTrue(actualVolWeightStockPrice == expectedVolWeightStockPrice);
	}
}
