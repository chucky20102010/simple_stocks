package simple.stocks.utils;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class UtilsTest {
	@Test(expected=IllegalArgumentException.class)
	public void calculateGBCEAllShareIndex_PassedNullStockPricesArray_ThrowsException(){
		List<Double> allStockPrices = null;
		Utils.calculateGBCEAllShareIndex(allStockPrices);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void calculateGBCEAllShareIndex_PassedEmptyStockPricesArray_ThrowsException(){
		List<Double> allStockPrices = new ArrayList<>();
		Utils.calculateGBCEAllShareIndex(allStockPrices);
	}
	
	@Test(expected=RuntimeException.class)
	public void calculateGBCEAllShareIndex_PassedNegativeStockPricesArray_ThrowsException(){
		List<Double> allStockPrices = Arrays.asList(-120.0,-100.0,-90.0);
		Utils.calculateGBCEAllShareIndex(allStockPrices);
	}
	
	@Test
	public void calculateGBCEAllShareIndex_PassedValidStockPricesArray_ReturnsCorrectCBGEAllShareIndex(){
		List<Double> allStockPrices = Arrays.asList(120.0,100.0,90.0);
		double actualGBCEAllShareIndex = Utils.calculateGBCEAllShareIndex(allStockPrices);
		double expectedGBCEAllShareIndex = 1039.2304845413264;
		assertTrue(actualGBCEAllShareIndex == expectedGBCEAllShareIndex);
		System.err.println(actualGBCEAllShareIndex);
	}

}
