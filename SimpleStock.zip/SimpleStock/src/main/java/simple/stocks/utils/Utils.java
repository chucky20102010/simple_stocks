package simple.stocks.utils;

import java.util.List;

public class Utils {
	public static double calculateGBCEAllShareIndex(List<Double> allStockPrices){
		if (allStockPrices == null || allStockPrices.isEmpty()){
			throw new IllegalArgumentException("allStockPrices array cannot be null or empty");
		}

		double productOfAllStockPrices = 1.0;
		for (double stockPrice : allStockPrices){
			if (stockPrice <= 0){
				throw new RuntimeException("Negative stock price encountered cannot continue");
			} else {
				productOfAllStockPrices *= stockPrice;
			}
		}		
		
		return Math.pow(productOfAllStockPrices, 0.5);
	}
}
