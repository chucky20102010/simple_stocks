package simple.stocks.implementations;

import java.util.ArrayList;
import java.util.List;

import simple.stocks.domain.StockType;
import simple.stocks.domain.TradeIndicator;
import simple.stocks.domain.TradeRecord;
import simple.stocks.interfaces.Stock;

public class StockImpl implements Stock {
	private List<TradeRecord> executedTrades = new ArrayList<>();
	private StockType type;
	private String symbol;
	private double lastDividend;
	private int parValue;
	private double currentDividend;
	
	public StockImpl(){
		super();
	}
	
	public StockImpl(String symbol,StockType type,double lastDividend,int parValue){
		this.symbol = symbol;
		this.type = type;
		this.lastDividend = lastDividend;
		this.parValue = parValue;
	}

	@Override
	public double calculateDividendYield(double marketPrice) throws Exception {
		if (marketPrice <= 0){
			throw new IllegalArgumentException("Market Price must be a positive double value");
		}
		
		if (this.type == StockType.PREFERRED){
			throw new Exception("Please call calculateDividendYield(marketPrice,ParValue) to calculate dividend yields for prefered stocks");
		}
		
		double dividendYield = ((this.lastDividend) / (marketPrice)) ;
		this.lastDividend = dividendYield;

		return dividendYield;
	}
	
	@Override
	public double calculateDividendYield(double marketPrice, double fixedDividend) throws Exception {
		if (marketPrice <=0){
			throw new IllegalArgumentException("Market Price must be a positive double value");
		}
		
		if (fixedDividend < 0){
			throw new IllegalArgumentException("Fixed dividend  must be a positive double value");
		}
		
		if (this.type == StockType.COMMON){
			throw new Exception("Please call calculateDividendYield(marketPrice) to calculate dividend yields for common stocks");
		}
		
		double dividendYield = ((fixedDividend * this.parValue)/(marketPrice));
		this.lastDividend = dividendYield;
		// TODO Auto-generated method stub
		return dividendYield;
	}


	@Override
	public double calculate_P_E_Ratio(double marketPrice) {
		if (marketPrice <=0){
			throw new IllegalArgumentException("Market Price must be a positive double value");
		}		
		//Don't need to check the stock type here as we updated lastDividend with the newest dividend yield
		//we calculated the dividend yield
		double peRatio = (marketPrice/lastDividend); 
		
		return peRatio;
	}

	@Override
	public boolean recordTrade(TradeRecord tradeRecord) {
		if (tradeRecord == null){
			throw new IllegalArgumentException("Trade record passed to recordTrade was null cannot save");
		}		
		boolean isSaved = false;
		
		if (!executedTrades.contains(tradeRecord)){
			executedTrades.add(tradeRecord);
			isSaved = true;
		}
		return isSaved;
	}

	@Override
	public double calculateVolWeightedStockPrice(List<TradeRecord> tradesRecords) {
		if (tradesRecords == null || tradesRecords.isEmpty()){
			throw new IllegalArgumentException("TradeRecords where null or empty cannot calculate the volume weighted stock price");
		}
		long totalQuantity = 0;
		double totalTradePriceTimesQuantity = 0.0;
		
		for (TradeRecord tradeRecord : tradesRecords){
			totalQuantity += tradeRecord.getQuantity();
			totalTradePriceTimesQuantity += ((tradeRecord.getTradePrice()) * (tradeRecord.getQuantity()));
		}
		
		double volWeightedStockPrice = ((totalTradePriceTimesQuantity) / (totalQuantity));
		
		return volWeightedStockPrice;
	}
}
