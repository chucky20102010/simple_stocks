package simple.stocks.interfaces;

import java.util.List;

import simple.stocks.domain.TradeIndicator;
import simple.stocks.domain.TradeRecord;

public interface Stock {
	/**
	 * Calculates the dividend yield for a given stock type and marketPrice. <br>
	 * For common symbols the dividend yield returned is based on <br>
	 * 			<b>Last dividend / MarketPrice </b> <br>
	 * @param marketPrice - current market price for stock
	 * @return dividendYield
	 * @throws Exception - throws an exception if you call this overloaded version on a PREFERRED stock
	 */
	double calculateDividendYield(double marketPrice) throws Exception;
	
	/**
	 * Calculates the dividend yield for a given stock type and marketPrice. <br>
	 * For preferred symbols the dividend yield returned is based on <br>
	 *  		<b>Fixed dividend * Par price / MarketPrice <b> <br>
	 * @param marketPrice - current market price for stock
	 * @param fixedDividend - fixed dividend as a percentage for this stock
	 * @return dividendYield
	 * @throws Exception - throws an exception if you call this overloaded version on a COMMON stock
	 */
	double calculateDividendYield(double marketPrice,double fixedDividend) throws Exception;
	/**
	 * Calculates the PE ratio for a given marketPrice based on <br>
	 *			<b>Market Price / Dividend<b><br>
	 * @param marketPrice - current market price for stock
	 * @return peRatio
	 */
	double calculate_P_E_Ratio(double marketPrice);
	/**
	 * Records  a trade for a given stock
	 * 
	 * @param tradeRecord - a record of a trade of a stock that includes the following fields
	 *  timeStamp - time trade was made
	 *  quantity - number of stocks that was traded
	 *  indicator - indicates if it was a BUY or SELL
	 *  tradePrice - price the stock was traded at
	 * @return boolean flag true indicates the record was saved, false if it was not
	 */
	boolean recordTrade(TradeRecord tradeRecord);
	/**
	 * Calculates the volume weighted stock price for a given trade from startTimeStamp to endTimeStamp. <br>
	 * The volume weighted stock price is based on <br>
	 * <b> <br>
	 * Sum of (trade prices for each time interval * quantity of trades for each time interval) / Sum of all quantities of trades </b> <br>
	 * 
	 * @param tradesRecords - trades recorded for this stock
	 * @return volumeWeightedStockPrice
	 */
	double calculateVolWeightedStockPrice(List<TradeRecord> tradesRecords);
}
