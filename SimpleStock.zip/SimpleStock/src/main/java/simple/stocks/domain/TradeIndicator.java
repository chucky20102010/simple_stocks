package simple.stocks.domain;

public enum TradeIndicator {
	BUY,SELL
}
