package simple.stocks.domain;

public enum StockType {
	COMMON,PREFFERRED, PREFERRED
}
