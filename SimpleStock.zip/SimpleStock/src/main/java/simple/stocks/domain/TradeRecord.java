package simple.stocks.domain;

public class TradeRecord {
	private final String timeStamp;
	private final long quantity;
	private final TradeIndicator indicator;
	private final double tradePrice;
	
	public TradeRecord(String timeStamp, long quantity, TradeIndicator indicator, double tradePrice) {
		super();
		this.timeStamp = timeStamp;
		this.quantity = quantity;
		this.indicator = indicator;
		this.tradePrice = tradePrice;
	}

	public long getQuantity() {
		return quantity;
	}

	public double getTradePrice() {
		return tradePrice;
	}
	
	//Can include override for equals and hashmap here for improvements to this code
}
